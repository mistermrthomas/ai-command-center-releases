## v0.9.2 — version-only rollback acceptance candidate

Owner-authorized version-only update. A one-time LOCAL health-failure marker will
exercise automatic rollback on the test Mac. No faulty executable is published.
Only version and release notes change; no database or credential changes.

## v0.9.1 — version-only automatic-update acceptance release

Owner-authorized harmless development test. Only VERSION and these release notes
change in the application payload. No executable, schema, credential or data
changes. Python regression suite and JavaScript syntax must pass before signing.

## v0.9.0 — 2026-11-09 — automatic updater bootstrap

Owner-approved scope: permanent development updates, backups, signing, launchd,
health checks and rollback. Implementer: Codex. No schema migration or redesign.

- Added isolated trusted updater and private GitHub Actions publishing workflow.
- Added pinned signing verification, file allowlists and replay protection.
- Added maintenance gating, protected SQLite/credential backups, restart health
  checks, interrupted-transaction recovery and rollback.
- Added version/process identity to local status and a stable local data directory
  setting so managed releases preserve the existing Muse/Grok configuration.
- Replaced personal details in the bundled demo with a generic public-safe example.
- Validation: 45 tests passed and JavaScript syntax passed. Live acceptance
  evidence: managed 0.9.0 restart and injected-failure rollback passed with
  unchanged data/credentials. GitHub CI passed. Public publication/automatic
  installation remains pending the scoped RELEASE_PUBLISH_TOKEN secret.
- Rollback: previous program directory plus protected backups; updater bootstrap
  changes require separate local approval. See UPDATES.md for limits and recovery.

## v0.9 — Daylight console and activity monitor
- Daytime light mode is now the default. The upper navigation stays dark. One-click light/dark toggle is saved locally per browser.
- New live activity panel shows queued, dispatched, completed, and ready-for-overseer states using only recorded server data.
- The open roundtable refreshes locally every five seconds, when visible. This does not call agent APIs or cost any tokens.
- Includes v0.8.1 fix: Collaborative uses the completed Muse assignment details and reuses completed Muse work.
- No database migration, no backend changes, no agent permission changes and no credential changes.

# AI Command Center — Source changelog

This file documents released code changes, not live agent actions. Cross-project completed actions can also be recorded in the local dashboard's **Change log**. All dates UTC unless noted.

## v0.8.1 — 2026-11-09

**Classification:** Routine bug fix. No UI redesign, database migrations, or credential changes.

- Start Collaborative now prefills the **full prompt from the latest completed Muse assignment**, rather than the original short discussion goal.
- If no completed Muse assignment exists, use the latest saved assignment before falling back to the discussion goal.
- When an existing completed Muse assignment will be reused, the review button explicitly says **Approve & start Grok (reuse Muse)**. This avoids implying Muse will run again.
- Owner still reviews and approves the exact outbound task; no new automated APIs, retries, or scheduling.

## v0.8 — 2026-11-09

**Classification:** Owner-requested Grok connection and narrowly scoped Collaborative orchestration. Existing styling retained.

- Added a localhost-only **Connect Grok** form: securely save the existing bot's routine webhook URL, sender key, and temporary HTTPS gateway origin without using Terminal or copying secrets into chat.
- Generate a unique Grok callback token (revealed one time in the local interface) and support explicit rotation. Existing Muse token remains unchanged.
- Added a single owner-approved **Start Collaborative** action. Reuses the latest completed Muse assignment for the discussion, queues an independent Grok assignment, and sends **at most one** webhook containing only the assignment ID and gateway address.
- Tracks workflow progress (`waiting_agents` vs `ready_for_overseer`) from verified assignments. Webhook acceptance is never interpreted as task completion.
- Preserves the default privacy-first policy: only approved assignment prompts are returned to agents; no transcript export or extra OpenAI/Gemini API calls occur automatically.
- Added a Mac update kit that backs up code, credentials, and a SQLite database snapshot, then replaces **only program files**. Does not replace the existing `.env`, database, or connected Muse state.
- Added regression tests for authenticated/local setup, rejected private URL destinations, scoped credentials, idempotent start, and no hidden API expenses.

**Verification:** 31 passing Python tests; `node --check` for frontend JavaScript; package integrity and preservation installer tests. The live Mac/Grok routine and visual browser workflow still require user-side confirmation. Grok's routine currently receives webhooks but needs updated permissions/instructions to GET tasks and POST replies. The automatic OpenAI overseer is not built.

## v0.7 — 2026-11-09

**Classification:** Minor feature and routine bug fixes. No major redesign.

- Added append-only SQLite `change_log` entries for implementation history across projects, including date, project, category, impact, implementer (as reported), details, verification, version/commit reference, and optional approval link.
- Added the local-only **Change log** section and entry form to the Overview dashboard.
- Added scoped change classification: routine low-risk bug fixes/minor visual fixes do not need prior approval, while major styles, major features, sensitive changes, deployments, spending, or significant impact do.
- Approval requests now include a change category. High-impact change-log records require a previously approved, matching category and exact summary. Old untyped approvals cannot authorize new major entries.
- Added automated regression tests for approval gating, append-only persistence, and isolation from the external agent gateway. Corrected hidden-modal styling so an intentionally closed modal remains hidden across browsers.
- Updated Codex instructions and build plan. No automatic agent tasks, external changes, or additional API charges enabled.

**Verification:** Local Python unit/integration tests (27) and JavaScript syntax check. These do not prove any live Grok/Muse integration or external deployment.

## v0.6 — 2026-11-09

- Local priority dashboard across projects with status, ownership and next action.
- Local approval queue and decision audit for major changes; no automatic execution on approval.

## v0.5 — 2026-11-09

- Privacy-minimized, manually reviewed outgoing prompts and narrowed agent assignment payloads.
- Added OpenAI creative/graphics role to planned orchestration.

## v0.4 — 2026-11-09

- Collaborative roundtable mode set as the default metadata for new discussions.

## v0.3 — 2026-11-09

- Added separate Grok Bot callback authentication and one-time webhook dispatch pilot.

## v0.2 — 2026-11-09

- Added Muse-only authenticated agent gateway, pending assignments and idempotent callback tests.

## v0.1 — 2026-11-09

- Initial local roundtable prototype with optional explicitly triggered API calls.
